const $=id=>document.getElementById(id);
function send(msg){return new Promise(resolve=>chrome.runtime.sendMessage(msg,resolve))}
function age(ms){if(!ms)return "Unknown";let mins=Math.max(0,Math.floor((Date.now()-ms)/60000));if(mins<60)return `${mins} min ago`;let h=Math.floor(mins/60);if(h<24)return `${h}h ago`;let d=Math.floor(h/24);return `${d} day${d===1?"":"s"} ago`}
function mood(n){return n<5?"😴":n<15?"🙂":n<30?"😋":"👺"}
let current=[];
async function load(){
 let r=await send({type:"GET_DATA"});if(!r?.ok){$("status").textContent=r?.error||"Could not read tabs";return}
 current=r.tabs;let n=current.length,asleep=current.filter(t=>t.discarded).length,kept=current.filter(t=>t.kept).length;
 $("total").textContent=n;$("asleep").textContent=asleep;$("kept").textContent=kept;$("goblin").textContent=mood(n);
 $("tabList").innerHTML="";
 if(!n){$("tabList").textContent="No tabs in this window."}
 current.forEach(t=>{
  let row=document.createElement("div");row.className="item";
  let info=document.createElement("div");info.className="info";
  let title=document.createElement("div");title.className="title";title.textContent=t.title;
  let url=document.createElement("div");url.className="url";url.textContent=t.discarded?"Asleep · click tab to wake":age(t.lastAccessed);
  info.append(title,url);
  let keep=document.createElement("button");keep.className="mini";keep.textContent=t.kept?"★":"☆";keep.title="Toggle Keep";keep.onclick=async()=>{await send({type:"TOGGLE_KEEP",id:t.id});load()};
  let sleep=document.createElement("button");sleep.className="mini";sleep.textContent=t.discarded?"Asleep":"Zzz";sleep.title="Put tab to sleep";sleep.disabled=t.discarded||t.active||t.pinned||t.kept;sleep.style.opacity=sleep.disabled?".45":"1";sleep.onclick=async()=>{let x=await send({type:"DISCARD",id:t.id});$("status").textContent=x.ok?"Tab put to sleep. It remains open and can wake when clicked.":x.error;load()};
  row.append(info,keep,sleep);$("tabList").append(row);
 });
 $("status").textContent=`${n} tabs in this window · ${asleep} sleeping · ${kept} protected`;
}
async function sessions(){
 let r=await send({type:"LIST_SESSIONS"});$("sessionList").innerHTML="";
 (r.sessions||[]).forEach(s=>{
  let d=document.createElement("div");d.className="session";
  let name=document.createElement("b");name.textContent=s.name;
  let meta=document.createElement("div");meta.className="muted";meta.textContent=`${s.tabs.length} tabs · ${new Date(s.savedAt).toLocaleString()}`;
  let restore=document.createElement("button");restore.className="mini";restore.textContent="Restore";restore.onclick=async()=>{let x=await send({type:"RESTORE_SESSION",id:s.id});$("status").textContent=x.ok?"Session restored in new tabs.":x.error};
  let del=document.createElement("button");del.className="mini";del.textContent="Delete";del.style.marginLeft="5px";del.onclick=async()=>{await send({type:"DELETE_SESSION",id:s.id});sessions()};
  d.append(name,meta,restore,del);$("sessionList").append(d);
 });
 if(!(r.sessions||[]).length)$("sessionList").textContent="No saved sessions yet.";
}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));$("tabsView").hidden=b.dataset.view!=="tabs";$("sessionsView").hidden=b.dataset.view!=="sessions";if(b.dataset.view==="sessions")sessions()});
$("save").onclick=async()=>{let name=prompt("Name this tab session:",`Session ${new Date().toLocaleDateString()}`);if(name===null)return;let r=await send({type:"SAVE_SESSION",name:name.trim()||"Saved session"});$("status").textContent=r.ok?"Session saved locally.":r.error};
$("feed").onclick=async()=>{let candidates=current.filter(t=>!t.active&&!t.pinned&&!t.kept&&!t.discarded);if(!candidates.length){$("status").textContent="No safe inactive tabs to put to sleep.";return}let done=0;for(let t of candidates){let r=await send({type:"DISCARD",id:t.id});if(r.ok)done++} $("status").textContent=`Goblin put ${done} tabs to sleep. Tabs remain open.`;load()};
load();
