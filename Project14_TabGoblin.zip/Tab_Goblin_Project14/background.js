const KEEP_KEY="tabGoblinKeep";
const SESSIONS_KEY="tabGoblinSessions";
async function getKeep(){let x=await chrome.storage.local.get(KEEP_KEY);return new Set(x[KEEP_KEY]||[])}
async function saveKeep(set){await chrome.storage.local.set({[KEEP_KEY]:[...set]})}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
 (async()=>{
  try{
   if(msg.type==="GET_DATA"){
    let tabs=await chrome.tabs.query({currentWindow:true}),keep=await getKeep();
    let data=tabs.map(t=>({id:t.id,title:t.title||t.url||"Untitled tab",url:t.url||"",active:!!t.active,pinned:!!t.pinned,discarded:!!t.discarded,lastAccessed:t.lastAccessed||0,kept:keep.has(t.id),favIconUrl:t.favIconUrl||""}));
    data.sort((a,b)=>a.lastAccessed-b.lastAccessed);
    sendResponse({ok:true,tabs:data,keep:[...keep]});
   }else if(msg.type==="TOGGLE_KEEP"){
    let keep=await getKeep();if(keep.has(msg.id))keep.delete(msg.id);else keep.add(msg.id);await saveKeep(keep);sendResponse({ok:true});
   }else if(msg.type==="DISCARD"){
    let tab=await chrome.tabs.get(msg.id),keep=await getKeep();
    if(keep.has(tab.id)||tab.pinned||tab.active){sendResponse({ok:false,error:"This tab is active, pinned or on your Keep list."});return}
    let result=await chrome.tabs.discard(tab.id);sendResponse({ok:!!result});
   }else if(msg.type==="SAVE_SESSION"){
    let tabs=await chrome.tabs.query({currentWindow:true});
    let session={id:Date.now(),name:msg.name||"Saved session",savedAt:new Date().toISOString(),tabs:tabs.map(t=>({url:t.url,title:t.title,pinned:t.pinned,active:t.active}))};
    let obj=await chrome.storage.local.get(SESSIONS_KEY),sessions=obj[SESSIONS_KEY]||[];
    sessions.unshift(session);await chrome.storage.local.set({[SESSIONS_KEY]:sessions.slice(0,20)});
    sendResponse({ok:true,session});
   }else if(msg.type==="LIST_SESSIONS"){
    let obj=await chrome.storage.local.get(SESSIONS_KEY);sendResponse({ok:true,sessions:obj[SESSIONS_KEY]||[]});
   }else if(msg.type==="RESTORE_SESSION"){
    let obj=await chrome.storage.local.get(SESSIONS_KEY),session=(obj[SESSIONS_KEY]||[]).find(x=>x.id===msg.id);
    if(!session){sendResponse({ok:false,error:"Saved session not found."});return}
    for(let t of session.tabs){if(t.url && /^(https?|file):/i.test(t.url)){await chrome.tabs.create({url:t.url,pinned:!!t.pinned,active:!!t.active})}}
    sendResponse({ok:true});
   }else if(msg.type==="DELETE_SESSION"){
    let obj=await chrome.storage.local.get(SESSIONS_KEY);let sessions=(obj[SESSIONS_KEY]||[]).filter(x=>x.id!==msg.id);await chrome.storage.local.set({[SESSIONS_KEY]:sessions});sendResponse({ok:true});
   }
  }catch(e){sendResponse({ok:false,error:e.message})}
 })();return true;
});
